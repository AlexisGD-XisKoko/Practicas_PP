public class Cuadrado {
    private String color;
    private double lado;

    public Cuadrado(String color, double lado) {
        this.color = color;
        this.lado = lado;
    }

    public String getColor() {
        return color;
    }

    public double getLado() {
        return lado;
    }

    public double getArea() {
        return calcularArea();
    }

    public double getPerimetro() {
        return calcularPerimetro();
    }

    private double calcularArea() {
        return lado * lado;
    }

    private double calcularPerimetro() {
        return 4 * lado;
    }
}
