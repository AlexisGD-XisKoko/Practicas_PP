//Guzman Dolores Alexis 28/04/24  - Paradigmas de Programacion 
//Clase Principal de las Figuras Geometricas

public class FigurasGeometricas {
    public static void main(String[] args) {
        // Crear objetos de las clases Circulo, Rectangulo, Cuadrado y Triangulo
        Circulo circulo = new Circulo("rojo", 5.0);
        Rectangulo rectangulo = new Rectangulo("verde", 4.0, 6.0);
        Cuadrado cuadrado = new Cuadrado("azul", 3.0);
        Triangulo triangulo = new Triangulo("amarillo", 3.0, 4.0, 5.0);

        // Mostrar información de cada figura
        System.out.println("Círculo:");
        System.out.println("Color: " + circulo.getColor());
        System.out.println("Radio: " + circulo.getRadio());
        System.out.println("Área: " + circulo.getArea());
        System.out.println("Perímetro: " + circulo.getPerimetro());

        System.out.println("\nRectángulo:");
        System.out.println("Color: " + rectangulo.getColor());
        System.out.println("Base: " + rectangulo.getBase());
        System.out.println("Altura: " + rectangulo.getAltura());
        System.out.println("Área: " + rectangulo.getArea());
        System.out.println("Perímetro: " + rectangulo.getPerimetro());

        System.out.println("\nCuadrado:");
        System.out.println("Color: " + cuadrado.getColor());
        System.out.println("Lado: " + cuadrado.getLado());
        System.out.println("Área: " + cuadrado.getArea());
        System.out.println("Perímetro: " + cuadrado.getPerimetro());

        System.out.println("\nTriángulo:");
        System.out.println("Color: " + triangulo.getColor());
        System.out.println("Lado 1: " + triangulo.getLado1());
        System.out.println("Lado 2: " + triangulo.getLado2());
        System.out.println("Lado 3: " + triangulo.getLado3());
        System.out.println("Área: " + triangulo.getArea());
        System.out.println("Perímetro: " + triangulo.getPerimetro());
    }
}