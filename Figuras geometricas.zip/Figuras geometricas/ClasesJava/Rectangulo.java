public class Rectangulo {
    private String color;
    private double base;
    private double altura;

    public Rectangulo(String color, double base, double altura) {
        this.color = color;
        this.base = base;
        this.altura = altura;
    }

    public String getColor() {
        return color;
    }

    public double getBase() {
        return base;
    }

    public double getAltura() {
        return altura;
    }

    public double getArea() {
        return calcularArea();
    }

    public double getPerimetro() {
        return calcularPerimetro();
    }

    private double calcularArea() {
        return base * altura;
    }

    private double calcularPerimetro() {
        return 2 * (base + altura);
    }
}
