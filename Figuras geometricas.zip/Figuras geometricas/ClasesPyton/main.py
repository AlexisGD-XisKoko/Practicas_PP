from hexagono import Hexagono
from rombo import Rombo
from trapecio import Trapecio

if __name__ == "__main__":
    hexagono = Hexagono("rojo", 5)
    print("Hexágono:")
    print("Color:", hexagono.get_color())
    print("Área:", hexagono.get_area())
    print("Perímetro:", hexagono.get_perimetro())

    rombo = Rombo("verde", 6, 8)
    print("\nRombo:")
    print("Color:", rombo.get_color())
    print("Área:", rombo.get_area())
    print("Perímetro:", rombo.get_perimetro())

    trapecio = Trapecio("azul", 6, 4, 5)
    print("\nTrapecio:")
    print("Color:", trapecio.get_color())
    print("Área:", trapecio.get_area())
    print("Perímetro:", trapecio.get_perimetro())
