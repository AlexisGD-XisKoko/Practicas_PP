import math

class Trapecio:
    def __init__(self, color, base_mayor, base_menor, altura):
        self.__color = color
        self.__base_mayor = base_mayor
        self.__base_menor = base_menor
        self.__altura = altura
    
    def get_color(self):
        return self.__color
    
    def get_area(self):
        return self.__area()
    
    def get_perimetro(self):
        return self.__perimetro()
    
    def __area(self):
        return ((self.__base_mayor + self.__base_menor) * self.__altura) / 2
    
    def __perimetro(self):
        lado = math.sqrt((self.__base_mayor - self.__base_menor) ** 2 + self.__altura ** 2)
        return self.__base_mayor + self.__base_menor + 2 * lado
