import math

class Rombo:
    def __init__(self, color, diagonal_mayor, diagonal_menor):
        self.__color = color
        self.__diagonal_mayor = diagonal_mayor
        self.__diagonal_menor = diagonal_menor
    
    def get_color(self):
        return self.__color
    
    def get_area(self):
        return self.__area()
    
    def get_perimetro(self):
        return self.__perimetro()
    
    def __area(self):
        return (self.__diagonal_mayor * self.__diagonal_menor) / 2
    
    def __perimetro(self):
        return 4 * math.sqrt((self.__diagonal_mayor / 2) ** 2 + (self.__diagonal_menor / 2) ** 2)
