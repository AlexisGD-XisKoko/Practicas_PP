import math

class Hexagono:
    def __init__(self, color, lado):
        self.__color = color
        self.__lado = lado
    
    def get_color(self):
        return self.__color
    
    def get_area(self):
        return self.__area()
    
    def get_perimetro(self):
        return self.__perimetro()
    
    def __area(self):
        return (3 * math.sqrt(3) * self.__lado ** 2) / 2
    
    def __perimetro(self):
        return 6 * self.__lado
