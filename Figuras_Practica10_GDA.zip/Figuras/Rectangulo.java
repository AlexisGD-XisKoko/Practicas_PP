public class Rectangulo extends Figuras{
    private int lado1,lado2;

    public Rectangulo(int l1, int l2, String c){
        super(c);
        l1=lado1;
        l2=lado2;
    }

    @Override
    public double area(){
        return lado1*lado2;
    }

    @Override
    public double perimetro(){
        return (2*lado1)+(2*lado2);
    }

    public int getLado1() {
        return lado1;
    }

    public int getLado2() {
        return lado1;
    }
}
