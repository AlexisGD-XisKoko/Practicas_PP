public class Circulo extends Figuras{
    private int radio;

    public Circulo(int r, String c){
        super(c);
        radio=r;
    }

    @Override
    public double area(){
        return Math.PI*radio*radio;
    }

    @Override
    public double perimetro(){
        return 2 * Math.PI * radio;
    }

    public int getRadio(){
        return radio;
    }
}
