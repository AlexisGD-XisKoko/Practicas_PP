public class Hexagono extends Figuras{
    private int lado;

    public Hexagono(int l, String c){
        super(c);
        lado=l;
    }

    @Override
    public double area(){
        return (3 * Math.sqrt(3) * Math.pow(lado, 2)) / 2;
    }

    @Override
    public double perimetro(){
        return 6 * lado;
    }

    public double getLado(){
        return lado;
    }
}
