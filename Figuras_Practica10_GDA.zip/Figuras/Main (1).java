import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;

public class Main {
    public static void main(String[] args) {
        Figuras f;
        f = new Triangulo(3,2,"rojo");

        // Imprimir los detalles del triángulo
        System.out.println("Triángulo:");
        System.out.println("Color: " + f.getColor());
        System.out.println("Área: " + f.area());
        System.out.println("Perímetro: " + f.perimetro());

        f=new Circulo(5,"verde");
        // Imprimir los detalles del circulo
        System.out.println("Círculo:");
        System.out.println("Color: " + f.getColor());
        System.out.println("Área: " + f.area());
        System.out.println("Perímetro: " + f.perimetro());

        f=new Rectangulo(5,2,"amarillo");
        // Imprimir los detalles del rectangulo
        System.out.println("Rectángulo:");
        System.out.println("Color: " + f.getColor());
        System.out.println("Área: " + f.area());
        System.out.println("Perímetro: " + f.perimetro());

        f=new Hexagono(10,"café");
        // Imprimir los detalles del hexagono
        System.out.println("Hexágono:");
        System.out.println("Color: " + f.getColor());
        System.out.println("Área: " + f.area());
        System.out.println("Perímetro: " + f.perimetro());
    }
}