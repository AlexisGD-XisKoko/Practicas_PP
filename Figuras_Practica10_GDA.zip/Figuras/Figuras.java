//Clase Figura
public abstract class Figuras{
    private String color;

    public Figuras(String c){
        color=c;
    }
    public String getColor(){
        return color;
    }
    public abstract double area();
    public abstract double perimetro();
}

