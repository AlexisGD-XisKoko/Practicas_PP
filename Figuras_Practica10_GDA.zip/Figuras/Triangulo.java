public class Triangulo extends Figuras{
    private int base, altura;

    public Triangulo(int b, int a, String c){
        super(c);
        base = b;
        altura = a;
    }

    @Override
    public double area(){
        return (base*altura)/2;
    }

    @Override
    public double perimetro(){
        double lado = Math.sqrt(Math.pow(base / 2.0, 2) + Math.pow(altura, 2));
        return 2 * lado + base;
    }

    public int getBase() {
        return base;
    }

    public int getAltura() {
        return altura;
    }

}