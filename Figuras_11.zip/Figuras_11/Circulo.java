public class Circulo implements Figuras {
    private int radio;
    private String color;

    public Circulo(int r, String c) {
        radio = r;
        color = c;
    }

    @Override
    public double area() {
        return Math.PI * radio * radio;
    }

    @Override
    public double perimetro() {
        return 2 * Math.PI * radio;
    }

    @Override
    public String getColor() {
        return color;
    }

    public int getRadio() {
        return radio;
    }
}
