// Interfaz Figuras
public interface Figuras {
    String getColor();
    double area();
    double perimetro();
}
