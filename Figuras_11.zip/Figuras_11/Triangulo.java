public class Triangulo implements Figuras {
    private int base, altura;
    private String color;

    public Triangulo(int b, int a, String c) {
        base = b;
        altura = a;
        color = c;
    }

    @Override
    public double area() {
        return (base * altura) / 2.0;
    }

    @Override
    public double perimetro() {
        double lado = Math.sqrt(Math.pow(base / 2.0, 2) + Math.pow(altura, 2));
        return 2 * lado + base;
    }

    @Override
    public String getColor() {
        return color;
    }

    public int getBase() {
        return base;
    }

    public int getAltura() {
        return altura;
    }
}
