public class Hexagono implements Figuras {
    private int lado;
    private String color;

    public Hexagono(int l, String c) {
        lado = l;
        color = c;
    }

    @Override
    public double area() {
        return (3 * Math.sqrt(3) * Math.pow(lado, 2)) / 2;
    }

    @Override
    public double perimetro() {
        return 6 * lado;
    }

    @Override
    public String getColor() {
        return color;
    }

    public int getLado() {
        return lado;
    }
}
