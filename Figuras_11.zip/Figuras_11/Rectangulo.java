public class Rectangulo implements Figuras {
    private int lado1, lado2;
    private String color;

    public Rectangulo(int l1, int l2, String c) {
        lado1 = l1;
        lado2 = l2;
        color = c;
    }

    @Override
    public double area() {
        return lado1 * lado2;
    }

    @Override
    public double perimetro() {
        return (2 * lado1) + (2 * lado2);
    }

    @Override
    public String getColor() {
        return color;
    }

    public int getLado1() {
        return lado1;
    }

    public int getLado2() {
        return lado2;
    }
}
