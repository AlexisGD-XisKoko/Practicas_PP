from abc import ABC, abstractmethod

# Definición de la interfaz Figure
class Figure(ABC):
    def __init__(self, color):
        self.color = color

    def getColor(self):
        return self.color

    @abstractmethod
    def perimeter(self):
        pass

    @abstractmethod
    def area(self):
        pass

# Implementación de la interfaz para Triangle
class Triangle(Figure):
    def __init__(self, base, height, color):
        super().__init__(color)
        self.base = base
        self.height = height

    def perimeter(self):
        side = (self.base ** 2 + self.height ** 2) ** 0.5
        return self.base + 2 * side

    def area(self):
        return (self.base * self.height) / 2

# Implementación de la interfaz para Circle
class Circle(Figure):
    def __init__(self, radius, color):
        super().__init__(color)
        self.radius = radius

    def perimeter(self):
        return 2 * 3.141592653589793 * self.radius

    def area(self):
        return 3.141592653589793 * (self.radius ** 2)

# Implementación de la interfaz para Rectangle
class Rectangle(Figure):
    def __init__(self, width, height, color):
        super().__init__(color)
        self.width = width
        self.height = height

    def perimeter(self):
        return 2 * (self.width + self.height)

    def area(self):
        return self.width * self.height

# Implementación de la interfaz para Hexagon
class Hexagon(Figure):
    def __init__(self, side, color):
        super().__init__(color)
        self.side = side

    def perimeter(self):
        return 6 * self.side

    def area(self):
        return (3 * (3 ** 0.5) * (self.side ** 2)) / 2

# Función principal
def main():
    shapes = [
        Triangle(10, 5, "rojo"),
        Circle(7, "azul"),
        Rectangle(8, 4, "verde"),
        Hexagon(6, "amarillo")
    ]

    for shape in shapes:
        print(f"{shape.__class__.__name__} - Color: {shape.getColor()}")
        print(f"Perimeter: {shape.perimeter()}")
        print(f"Area: {shape.area()}")
        print()

if __name__ == "__main__":
    main()
